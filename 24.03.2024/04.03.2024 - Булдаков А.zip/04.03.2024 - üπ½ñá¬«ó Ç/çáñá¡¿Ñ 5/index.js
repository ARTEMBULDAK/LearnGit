const button=[...document.querySelectorAll('.button')]
const box=[...document.querySelectorAll('.box')]




box.forEach(box=>{
   console.log(box)
   let btn=box.querySelector('.button')
   console.log(btn)
   btn.addEventListener('click', ()=>{
      box.remove()
   })
}
)  



// button.forEach(btn => btn.addEventListener('click',closer));


// function closer(event){
//    console.log(event.target.parentNode.parentNode.remove())

// }