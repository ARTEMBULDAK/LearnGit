button=document.querySelector('.button')
text=document.querySelector('.text')



button.addEventListener('click',abc);
// button.addEventListener('click',cba);


function abc(){
    text.hidden = !text.hidden;

}

// function cba(){
//     text.style.display='flex';
// }