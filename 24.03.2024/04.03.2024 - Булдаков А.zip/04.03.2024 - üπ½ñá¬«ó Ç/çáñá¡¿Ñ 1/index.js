number=document.querySelector('.number')
button=document.querySelector('.button')



button.addEventListener('click',randomNumber);

let min=1
let max=100
function abc(min,max){
   return Math.random() * (max - min) + min;
    // let randomNumber = Math.random()
    number.innerHTML=`${a}`
    console.log(a)
}


let div = document.getElementById('result');
let from = document.getElementById('from');
let to = document.getElementById('to');


function randomNumber(){
  let min =  0;
  let max =  100;
  let num = min + Math.floor(Math.random() * (max-min));
  number.innerHTML = `${num}`;
}
