const btn = document.getElementById('btn');
let storage = localStorage.getItem('_cnt') ?? 0;
btn.innerHTML = storage;
 
btn.addEventListener('click', e => {
    e.target.innerHTML = ++storage;
    localStorage.setItem('_cnt', storage);
});