var width = 5;

function move() {
  var elem = document.getElementById("myBar");
    if (width < 100) {
      width+=5;
      elem.style.width = width + '%';
      elem.innerHTML = width * 1 + '%';
    }
  
}