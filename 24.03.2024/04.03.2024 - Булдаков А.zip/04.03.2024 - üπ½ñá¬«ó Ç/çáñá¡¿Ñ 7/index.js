document.querySelector('#tab').addEventListener('mouseover', function(e){
    const trg = e.target;
    if(trg.tagName !== 'TD' || trg.closest('tr') == document.querySelector('tr:first-of-type')) return;
    trg.classList.add('hovered');
    trg.onmouseout = function(){this.classList.remove('hovered');}
   });  